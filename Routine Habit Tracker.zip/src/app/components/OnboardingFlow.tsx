import React, { useState } from 'react';
import { Sparkles, ArrowRight, Check, Target } from 'lucide-react';
import * as Icons from 'lucide-react';
import { HABIT_TEMPLATES, TEMPLATE_CATEGORIES } from '@/types/templates';
import { Habit } from '@/types/habit';

interface OnboardingFlowProps {
  isOpen: boolean;
  onComplete: (selectedTemplates: string[]) => void;
}

export function OnboardingFlow({ isOpen, onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);

  if (!isOpen) return null;

  const filteredTemplates = selectedCategory === 'all'
    ? HABIT_TEMPLATES
    : HABIT_TEMPLATES.filter(t => t.category === selectedCategory);

  const handleTemplateToggle = (templateId: string) => {
    if (selectedTemplates.includes(templateId)) {
      setSelectedTemplates(selectedTemplates.filter(id => id !== templateId));
    } else {
      if (selectedTemplates.length < 3) {
        setSelectedTemplates([...selectedTemplates, templateId]);
      }
    }
  };

  const handleContinue = () => {
    if (step === 1) {
      setStep(2);
    } else if (step === 2) {
      if (selectedTemplates.length > 0) {
        setStep(3);
      }
    } else {
      onComplete(selectedTemplates);
    }
  };

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 z-50 overflow-hidden">
      {step === 1 && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="max-w-2xl w-full text-center text-white">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mb-8 animate-bounce">
              <Sparkles className="w-12 h-12" />
            </div>
            
            <h1 className="text-5xl font-bold mb-4">
              루틴 습관 트래커
            </h1>
            
            <p className="text-2xl mb-3 text-white/90">
              의지보다 회복력을 설계하는
            </p>
            
            <p className="text-xl mb-12 text-white/80">
              완벽하지 않아도 괜찮아요. 함께 시작해봐요! ✨
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Target className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">Elastic 목표</h3>
                <p className="text-sm text-white/80">완벽 목표와 최소 목표를 함께 설정</p>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">Recovery Mode</h3>
                <p className="text-sm text-white/80">실패 후 가볍게 다시 시작</p>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-lg mb-2">쉼표 기록</h3>
                <p className="text-sm text-white/80">못한 것도 기록하며 패턴 파악</p>
              </div>
            </div>

            <button
              onClick={handleContinue}
              className="inline-flex items-center gap-3 px-12 py-5 bg-white text-purple-600 font-bold text-lg rounded-full hover:bg-white/90 transition-all shadow-2xl hover:shadow-3xl"
            >
              10초만에 시작하기
              <ArrowRight className="w-6 h-6" />
            </button>

            <p className="text-sm text-white/60 mt-6">
              첫 3일은 실패해도 괜찮아요 (Beginner's Grace Period)
            </p>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="max-w-4xl w-full">
            <div className="text-center text-white mb-8">
              <h2 className="text-4xl font-bold mb-3">
                어떤 습관을 시작하고 싶나요?
              </h2>
              <p className="text-lg text-white/80">
                템플릿을 선택하거나 나중에 직접 만들 수 있어요 (최대 3개)
              </p>
              <p className="text-sm text-white/60 mt-2">
                선택: {selectedTemplates.length}/3
              </p>
            </div>

            {/* Categories */}
            <div className="flex gap-3 mb-6 overflow-x-auto pb-2">
              {TEMPLATE_CATEGORIES.map(cat => {
                const Icon = (Icons as any)[cat.icon];
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`flex items-center gap-2 px-5 py-3 rounded-full font-medium transition-all whitespace-nowrap ${
                      selectedCategory === cat.id
                        ? 'bg-white text-purple-600'
                        : 'bg-white/20 text-white hover:bg-white/30'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {cat.label}
                  </button>
                );
              })}
            </div>

            {/* Templates Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {filteredTemplates.map(template => {
                const IconComponent = (Icons as any)[template.icon];
                const isSelected = selectedTemplates.includes(template.id);
                
                return (
                  <button
                    key={template.id}
                    onClick={() => handleTemplateToggle(template.id)}
                    disabled={!isSelected && selectedTemplates.length >= 3}
                    className={`relative bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-left transition-all border-2 ${
                      isSelected
                        ? 'border-white bg-white/20 scale-105'
                        : 'border-white/20 hover:border-white/40 hover:bg-white/15'
                    } ${!isSelected && selectedTemplates.length >= 3 ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {isSelected && (
                      <div className="absolute top-4 right-4 w-6 h-6 bg-white rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-purple-600" />
                      </div>
                    )}
                    
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                      style={{ backgroundColor: template.color }}
                    >
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    
                    <h3 className="font-bold text-white text-lg mb-2">{template.title}</h3>
                    <p className="text-sm text-white/70 mb-3">{template.defaultReason}</p>
                    
                    <div className="flex items-center gap-2 text-xs text-white/60">
                      <span className="px-2 py-1 bg-white/10 rounded">
                        {template.difficulty === 'easy' ? '쉬움' : template.difficulty === 'medium' ? '보통' : '어려움'}
                      </span>
                      <span className="px-2 py-1 bg-white/10 rounded">
                        {template.period}일
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => onComplete([])}
                className="flex-1 py-4 bg-white/20 text-white font-semibold rounded-xl hover:bg-white/30 transition-all"
              >
                건너뛰고 직접 만들기
              </button>
              
              <button
                onClick={handleContinue}
                disabled={selectedTemplates.length === 0}
                className={`flex-1 py-4 font-semibold rounded-xl transition-all ${
                  selectedTemplates.length > 0
                    ? 'bg-white text-purple-600 hover:bg-white/90'
                    : 'bg-white/20 text-white/50 cursor-not-allowed'
                }`}
              >
                다음 ({selectedTemplates.length}개 선택)
              </button>
            </div>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="max-w-2xl w-full text-center text-white">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full mb-8">
              <Check className="w-12 h-12" />
            </div>
            
            <h2 className="text-4xl font-bold mb-4">
              준비 완료! 🎉
            </h2>
            
            <p className="text-xl mb-12 text-white/90">
              {selectedTemplates.length}개의 습관이 추가되었어요.<br />
              지금 바로 시작해볼까요?
            </p>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 mb-8">
              <h3 className="font-bold text-lg mb-4">💡 시작 가이드</h3>
              <div className="space-y-3 text-left text-white/80">
                <p>✨ 첫 3일은 실패해도 괜찮아요 (Beginner's Grace Period)</p>
                <p>🎯 완벽 목표를 달성하면 최고! 최소 목표만 달성해도 Streak 유지</p>
                <p>💪 3일 연속 미달성 시 Recovery Mode가 자동으로 켜져요</p>
                <p>📝 못한 날도 '쉼표 기록'으로 패턴을 파악할 수 있어요</p>
              </div>
            </div>

            <button
              onClick={() => onComplete(selectedTemplates)}
              className="inline-flex items-center gap-3 px-12 py-5 bg-white text-purple-600 font-bold text-lg rounded-full hover:bg-white/90 transition-all shadow-2xl"
            >
              시작하기
              <ArrowRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}

      {/* Progress Indicator */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 flex gap-2">
        {[1, 2, 3].map(s => (
          <div
            key={s}
            className={`w-2 h-2 rounded-full transition-all ${
              s === step ? 'w-8 bg-white' : 'bg-white/40'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
