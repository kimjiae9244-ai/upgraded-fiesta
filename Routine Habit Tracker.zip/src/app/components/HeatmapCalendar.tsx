import React from 'react';
import { Habit, HabitLog } from '@/types/habit';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, addDays, subMonths, addMonths } from 'date-fns';
import { ko } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface HeatmapCalendarProps {
  habits: Habit[];
  logs: HabitLog[];
  currentDate?: Date;
  onDateChange?: (date: Date) => void;
}

export function HeatmapCalendar({ habits, logs, currentDate = new Date(), onDateChange }: HeatmapCalendarProps) {
  const [viewDate, setViewDate] = React.useState(currentDate);

  const monthStart = startOfMonth(viewDate);
  const monthEnd = endOfMonth(viewDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Get the starting day of the week (0 = Sunday, 1 = Monday, etc.)
  const startDayOfWeek = getDay(monthStart);
  
  // Add empty days at the start to align with the calendar
  const emptyDays = Array.from({ length: startDayOfWeek }, (_, i) => i);

  const getCompletionRate = (date: Date): number => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayLogs = logs.filter(log => log.date === dateStr && log.completed);
    
    if (habits.length === 0) return 0;
    return Math.round((dayLogs.length / habits.length) * 100);
  };

  const getHeatmapColor = (rate: number): string => {
    if (rate === 0) return 'bg-gray-100';
    if (rate < 25) return 'bg-purple-100';
    if (rate < 50) return 'bg-purple-200';
    if (rate < 75) return 'bg-purple-400';
    return 'bg-gradient-to-br from-purple-500 to-pink-500';
  };

  const goToPreviousMonth = () => {
    const newDate = subMonths(viewDate, 1);
    setViewDate(newDate);
    onDateChange?.(newDate);
  };

  const goToNextMonth = () => {
    const newDate = addMonths(viewDate, 1);
    setViewDate(newDate);
    onDateChange?.(newDate);
  };

  const weekDays = ['일', '월', '화', '수', '목', '금', '토'];

  return (
    <div className="bg-white rounded-2xl p-6 shadow-md">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">
          {format(viewDate, 'yyyy년 M월', { locale: ko })}
        </h3>
        
        <div className="flex gap-2">
          <button
            onClick={goToPreviousMonth}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
          <button
            onClick={goToNextMonth}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-2 mb-2">
        {weekDays.map(day => (
          <div key={day} className="text-center text-sm font-semibold text-gray-500 py-2">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {emptyDays.map(i => (
          <div key={`empty-${i}`} className="aspect-square" />
        ))}
        
        {daysInMonth.map(day => {
          const completionRate = getCompletionRate(day);
          const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
          const isFuture = day > new Date();
          
          return (
            <div
              key={format(day, 'yyyy-MM-dd')}
              className={`aspect-square rounded-lg flex items-center justify-center text-sm font-medium transition-all relative group ${
                isFuture
                  ? 'bg-gray-50 text-gray-300 cursor-not-allowed'
                  : getHeatmapColor(completionRate) + ' text-gray-700 hover:scale-110 cursor-pointer'
              } ${isToday ? 'ring-2 ring-purple-600 ring-offset-2' : ''}`}
              title={`${format(day, 'M월 d일')} - ${completionRate}% 달성`}
            >
              {format(day, 'd')}
              
              {!isFuture && completionRate > 0 && (
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 rounded-lg text-white text-xs font-bold">
                  {completionRate}%
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-6 flex items-center justify-between text-xs text-gray-600">
        <span>적음</span>
        <div className="flex gap-1">
          <div className="w-4 h-4 bg-gray-100 rounded"></div>
          <div className="w-4 h-4 bg-purple-100 rounded"></div>
          <div className="w-4 h-4 bg-purple-200 rounded"></div>
          <div className="w-4 h-4 bg-purple-400 rounded"></div>
          <div className="w-4 h-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded"></div>
        </div>
        <span>많음</span>
      </div>
    </div>
  );
}
