
  # Routine Habit Tracker

  This is a code bundle for Routine Habit Tracker. The original project is available at https://www.figma.com/design/9QUEcF45u6JWL4d1CNCqE0/Routine-Habit-Tracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  