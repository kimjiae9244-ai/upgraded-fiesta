export interface HabitTemplate {
  id: string;
  title: string;
  icon: string;
  color: string;
  category: 'health' | 'productivity' | 'learning' | 'lifestyle';
  frequency: 'daily' | 'weekly';
  perfectGoal: number;
  minGoal: number;
  difficulty: 'easy' | 'medium' | 'hard';
  period: 21 | 66 | 100;
  defaultReason: string;
}

export const HABIT_TEMPLATES: HabitTemplate[] = [
  // 건강
  {
    id: 'morning-exercise',
    title: '아침 운동하기',
    icon: 'Dumbbell',
    color: '#EC4899',
    category: 'health',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 70,
    difficulty: 'medium',
    period: 21,
    defaultReason: '건강한 하루를 시작하기 위해'
  },
  {
    id: 'water-intake',
    title: '물 2L 마시기',
    icon: 'Coffee',
    color: '#3B82F6',
    category: 'health',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 80,
    difficulty: 'easy',
    period: 21,
    defaultReason: '건강한 몸을 위해'
  },
  {
    id: 'meditation',
    title: '명상하기',
    icon: 'Heart',
    color: '#8B5CF6',
    category: 'health',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 70,
    difficulty: 'medium',
    period: 21,
    defaultReason: '마음의 평화를 위해'
  },
  
  // 생산성
  {
    id: 'reading',
    title: '책 읽기',
    icon: 'Book',
    color: '#10B981',
    category: 'productivity',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 60,
    difficulty: 'medium',
    period: 66,
    defaultReason: '지식을 쌓고 성장하기 위해'
  },
  {
    id: 'coding',
    title: '코딩 공부하기',
    icon: 'Code',
    color: '#F59E0B',
    category: 'learning',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 70,
    difficulty: 'hard',
    period: 100,
    defaultReason: '개발 실력을 향상시키기 위해'
  },
  {
    id: 'journaling',
    title: '일기 쓰기',
    icon: 'PenTool',
    color: '#EF4444',
    category: 'lifestyle',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 60,
    difficulty: 'easy',
    period: 21,
    defaultReason: '하루를 돌아보고 기록하기 위해'
  },
  
  // 학습
  {
    id: 'language',
    title: '외국어 공부',
    icon: 'Laptop',
    color: '#6366F1',
    category: 'learning',
    frequency: 'daily',
    perfectGoal: 100,
    minGoal: 70,
    difficulty: 'medium',
    period: 100,
    defaultReason: '새로운 언어를 배우기 위해'
  },
  {
    id: 'drawing',
    title: '그림 그리기',
    icon: 'Palette',
    color: '#14B8A6',
    category: 'lifestyle',
    frequency: 'weekly',
    perfectGoal: 100,
    minGoal: 60,
    difficulty: 'medium',
    period: 66,
    defaultReason: '창의력을 키우기 위해'
  }
];

export const TEMPLATE_CATEGORIES = [
  { id: 'all', label: '전체', icon: 'Star' },
  { id: 'health', label: '건강', icon: 'Heart' },
  { id: 'productivity', label: '생산성', icon: 'Zap' },
  { id: 'learning', label: '학습', icon: 'Book' },
  { id: 'lifestyle', label: '라이프스타일', icon: 'Smile' }
] as const;
